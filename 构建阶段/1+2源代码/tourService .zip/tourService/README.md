# travel
基于SSM的旅游信息管理系统

项目分前后台

前台
地址：http://localhost/index
账号：user  密码：123456

后台
地址：http://localhost/login
账号：root  密码：123456

功能模块：旅游路线、旅游景点、旅游酒店、旅游车票、旅游保险、旅游策略、订单管理、留言管理、数据分析等等。